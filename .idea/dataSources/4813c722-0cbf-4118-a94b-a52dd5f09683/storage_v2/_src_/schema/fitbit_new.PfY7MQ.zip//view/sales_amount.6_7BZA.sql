create definer = root@localhost view sales_amount as
select `fitbit_new`.`sales`.`tran_id`                                   AS `tran_id`,
       `fitbit_new`.`sales`.`date`                                      AS `date`,
       `fitbit_new`.`sales`.`product_id`                                AS `product_id`,
       `fitbit_new`.`sales`.`client_id`                                 AS `client_id`,
       `fitbit_new`.`sales`.`price`                                     AS `price`,
       `fitbit_new`.`sales`.`quantity`                                  AS `quantity`,
       (`fitbit_new`.`sales`.`price` * `fitbit_new`.`sales`.`quantity`) AS `amount`
from `fitbit_new`.`sales`;

