create definer = root@localhost view product_sales as
select `p`.`name`           AS `name`,
       sum(`s`.`amount`)    AS `total_amount`,
       count(`s`.`tran_id`) AS `cnt_tran`,
       min(`s`.`amount`)    AS `min_amount`,
       max(`s`.`amount`)    AS `max_amount`,
       sum(`s`.`quantity`)  AS `total_unints`
from `fitbit_new`.`sales_amount` `s`
         join `fitbit_new`.`product` `p`
where (`s`.`product_id` = `p`.`product_id`)
group by `p`.`name`
order by `total_amount` desc;

